/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.caminoeuleriano;
import java.util.*;
/**
 *
 * @author Usuario
 */
public class CaminoEuleriano {
    private int[][] graph;
    private int numVertices;
    private List<Integer> path;

    public CaminoEuleriano(int[][] graph) {
        this.graph = graph;
        this.numVertices = graph.length;
        this.path = new ArrayList<>();
    }

    public List<Integer> findEulerianPath() {
        path.clear();

        // Find a vertex with an odd degree (if any)
        int startVertex = findStartVertex();
        if (startVertex == -1) {
            // All vertices have even degree, find any vertex as the start
            startVertex = 0;
        }

        // Perform a depth-first search to find the Eulerian path
        dfs(startVertex);

        return path;
    }

    private void dfs(int v) {
        path.add(v);        
        for (int u = 0; u < numVertices; u++) {
            if (graph[v][u] > 0) {
                // Visit the edge (v, u)
                System.out.println("Visiting edge (" + v + ", " + u + ")");
                graph[v][u]--;
                graph[u][v]--;
                dfs(u);
            }
        }
        
        System.out.println("Adding vertex " + v + " to the path");
    }

    private int findStartVertex() {
        for (int v = 0; v < numVertices; v++) {
            int degree = 0;
            for (int u = 0; u < numVertices; u++) {
                degree += graph[v][u];
            }
            if (degree % 2 != 0) {
                return v;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[][] graph = {
            {0, 1, 0, 1, 0},
            {1, 0, 1, 1, 1},
            {0, 1, 0, 0, 1},
            {1, 1, 0, 0, 1},
            {0, 1, 1, 1, 0}
        };

        CaminoEuleriano eulerianPath = new CaminoEuleriano(graph);
        List<Integer> path = eulerianPath.findEulerianPath();

        if (!path.isEmpty()) {
           System.out.println("Eulerian Path: " + path);
        } else {
           System.out.println("No Eulerian Path found");
        }
    }
}
